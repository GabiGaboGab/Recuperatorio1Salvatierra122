
package gestionfestivalciencias;

public interface Reservable {
    int reservarLugar();
    int getCuposDisponibles();
}
