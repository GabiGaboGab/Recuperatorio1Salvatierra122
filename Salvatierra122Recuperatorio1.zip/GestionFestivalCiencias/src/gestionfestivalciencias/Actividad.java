package gestionfestivalciencias;

import java.util.Objects;

public abstract class Actividad {

    private final String codigo;
    private final String titulo;
    private final FranjaHoraria franjaHoraria;
    protected final int duracionBase;

    public Actividad(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase) {
        validarNulo(codigo);
        validarString(codigo);
        validarNulo(titulo);
        validarString(titulo);
        validarNulo(franjaHoraria);
        validarNulo(duracionBase);
        validarDurBase(duracionBase);
        this.codigo = codigo;
        this.titulo = titulo;
        this.franjaHoraria = franjaHoraria;
        this.duracionBase = duracionBase;
    }
/**
 * Valida nulo
 * @param o parametro a validar
 */
    protected void validarNulo(Object o) {
        if (o == null) {
            throw new IllegalArgumentException("El dato no debe ser nulo.");
        }

    }
/**
 * valida String
 * @param s parametro a validar
 */
    protected void validarString(String s) {
        if (s == null || s.isBlank()) {
            throw new IllegalArgumentException("El dato es obligatorio.");
        }
    }

    private void validarDurBase(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("El dato debe ser positivo.");
        }

    }

    protected void validarPositivo(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("El dato debe ser positivo.");
        }

    }
    
    public String descripcion(){
    return codigo + " " + titulo + " ";
    }

    protected void validarMinutos(int i) {

    }
    public abstract int duracionTotal();
    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public FranjaHoraria getFranjaHoraria() {
        return franjaHoraria;
    }

    public int getDuracionBase() {
        return duracionBase;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("|Código: ").append(codigo);
        sb.append("|Titulo: ").append(titulo);
        sb.append("|Franja Horaria: ").append(franjaHoraria);
        sb.append("|Duración base: ").append(duracionBase);
        return sb.toString();

    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo, titulo);
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Actividad a)) {
            return false;
        }
        return codigo.equals(a.codigo) && titulo.equals(a.titulo);
    }
}
