package gestionfestivalciencias;

public class MuestraInteractiva extends Actividad implements Presentable {

    private static final int DURACION_EXTRA = 5;
    private final int cantEstaciones;

    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase, int cantEstaciones) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        this.cantEstaciones = cantEstaciones;
    }

    public int getCantEstaciones() {
        return cantEstaciones;
    }

    @Override
    public String presentarseAlPublico() {
        return "Esta es la muestra interactiva: " + descripcion() + ".";
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("|Cantidad de estaciones: ").append(cantEstaciones);
        return sb.toString();

    }

    @Override
    public int duracionTotal() {
        return duracionBase + DURACION_EXTRA * cantEstaciones;
    }

}
