
package gestionfestivalciencias;


public interface Presentable {
    String presentarseAlPublico();
    
}
