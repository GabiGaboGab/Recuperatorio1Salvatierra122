package gestionfestivalciencias;

public class Taller extends Actividad implements Reservable {

    private final int minutosPractica;
    private int cuposDisponibles;

    public Taller(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase, int minutosPractica, int cuposDisponibles) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        validarPositivo(minutosPractica);
        this.cuposDisponibles = cuposDisponibles;
        this.minutosPractica = minutosPractica;
    }

/**
 *  Obtiene los minutos de practica
 * @return  (int) retorna los minutos de practica
 * 
 */
    public int getMinutosPractica() {
        return minutosPractica;
    }
/**
 * Reserva un lugar en la feria
 * @return (int) devuelve la cantidad de cupos
 */
    @Override
    public int reservarLugar() {
        if (getCuposDisponibles() <= 0) {
            throw new IllegalStateException("No quedan mas lugares");

        }
       return this.cuposDisponibles--;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("|Minutos de practica: ").append(minutosPractica);
        sb.append("|Cupos: ").append(cuposDisponibles);
        return sb.toString();

    }

    @Override
    public int getCuposDisponibles() {
        return this.cuposDisponibles--;
    }

    @Override
    public int duracionTotal() {
        return minutosPractica + duracionBase;
    }

}
