
package gestionfestivalciencias;

public class ActividadDuplicadaException extends Exception{
    private static String MESSAGE = "Esta actividad ya se encuentra registrada...";

    public ActividadDuplicadaException() {
        super(MESSAGE);
    }
    
    public ActividadDuplicadaException(String msg) {
        super(msg);
    }
    
    
    
}
