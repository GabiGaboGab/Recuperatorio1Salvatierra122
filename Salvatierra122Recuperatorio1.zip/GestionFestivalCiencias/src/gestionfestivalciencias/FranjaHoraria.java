package gestionfestivalciencias;

public enum FranjaHoraria {
    MATUTINA,
    VESPERTINA,
    NOCTURNA;
    
    @Override
    public String toString(){
    String texto = name();
    return texto.substring(0,1).toUpperCase() + texto.substring(1).toLowerCase();
    }

}
