package gestionfestivalciencias;

import java.util.ArrayList;
import java.util.List;

public class Festival {

    private final String nombre;
    private final List<Actividad> actividades;

    public Festival(String nombre, List<Actividad> actividades) {
        validarString(nombre);
        this.nombre = nombre;
        this.actividades = actividades;
    }

    public String getNombre() {
        return nombre;
    }

    private void validarNulo(Object o) {
        if (o == null) {
            throw new IllegalArgumentException("El dato no debe ser nulo.");
        }

    }

    private void validarString(String s) {
        if (s == null || s.isBlank()) {
            throw new IllegalArgumentException("El dato es obligatorio.");
        }
    }

    private void validarRepetido(Actividad act) throws ActividadDuplicadaException {
        if (actividades.contains(act)) {
            throw new ActividadDuplicadaException("Esta actividad ya se encuentra en la feria.");
        }
    }

    public void agregarActividad(Actividad a) throws ActividadDuplicadaException {
        validarNulo(a);
        validarRepetido(a);
        actividades.add(a);

    }

    public List<Actividad> obtenerActividades() {
        return new ArrayList<>(actividades);

    }

    public List<Actividad> filtrarPorFranja(FranjaHoraria fh) {
        validarNulo(fh);
        ArrayList<Actividad> listaFranjas = new ArrayList<>();
        for (Actividad a : actividades) {
            if (a.getFranjaHoraria() == fh) {
                listaFranjas.add(a);
            }

        }

        return listaFranjas;
    }

    public List<Actividad> obtenerActividadesDeDuracionMaxima(int durMax) {
        validarNulo(durMax);
        ArrayList<Actividad> listaDurMax = new ArrayList<>();
        for (Actividad a : actividades) {
            if (durMax <= a.duracionTotal()) {
                listaDurMax.add(a);
            }

        }
        return listaDurMax;
    }

}
