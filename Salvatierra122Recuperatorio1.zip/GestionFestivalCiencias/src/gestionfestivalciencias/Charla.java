package gestionfestivalciencias;

public class Charla extends Actividad implements Reservable, Presentable {

    private final int minutosPregunta;
    private int cuposDisponibles;

    public Charla(String codigo, String titulo, FranjaHoraria franjaHoraria, int duracionBase, int minutosPregunta, int cuposDisponibles) {
        super(codigo, titulo, franjaHoraria, duracionBase);
        validarPositivo(minutosPregunta);
        this.cuposDisponibles = cuposDisponibles;
        this.minutosPregunta = minutosPregunta;
    }


    
    
    public int getMinutosPregunta() {
        return minutosPregunta;
    }

    @Override
    public int reservarLugar() {
        if (getCuposDisponibles() <= 0){
            throw new  IllegalStateException("No quedan mas lugares");
        
        }
        return this.cuposDisponibles --;
    }
    @Override
    public int getCuposDisponibles(){
    return this.cuposDisponibles--;
    }

    @Override
    public String presentarseAlPublico() {
        return "Esta es la muestra interactiva: " + descripcion() + ".";
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("|Minutos por pregunta: ").append(minutosPregunta);
        sb.append("|Cupos: ").append(cuposDisponibles);
        return sb.toString();

    }

    @Override
    public int duracionTotal() {
        return duracionBase + minutosPregunta;
    }

}
